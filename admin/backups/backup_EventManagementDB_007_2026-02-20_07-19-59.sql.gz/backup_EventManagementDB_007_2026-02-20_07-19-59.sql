-- SQL Server Database Backup
-- Database: EventManagementDB_007
-- Generated: 2026-02-20 07:19:59

-- Table: Attendees_007
IF OBJECT_ID(N'Attendees_007', N'U') IS NOT NULL DROP TABLE Attendees_007;
CREATE TABLE Attendees_007 (
    attendee_id INT NOT NULL,
    email NVARCHAR(100) NOT NULL,
    password NVARCHAR(255) NOT NULL,
    full_name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20) NULL,
    address NVARCHAR(255) NULL,
    loyalty_points INT NULL DEFAULT ((0)),
    created_at DATETIME2 NULL DEFAULT (getdate()),
    updated_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (attendee_id)
);


INSERT INTO Attendees_007 (attendee_id, email, password, full_name, phone, address, loyalty_points, created_at, updated_at) VALUES (1, N'akua.mensah@gmail.com', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'Akua Mensah', N'+233-24-111-2222', N'15 Oxford Street, Osu, Accra', 150, N'2026-02-18 18:27:21.4000000', N'2026-02-18 18:27:21.4000000');
INSERT INTO Attendees_007 (attendee_id, email, password, full_name, phone, address, loyalty_points, created_at, updated_at) VALUES (2, N'yaw.owusu@gmail.com', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'Yaw Owusu', N'+233-20-333-4444', N'10 Ring Road, Cantonments, Accra', 75, N'2026-02-18 18:27:21.4000000', N'2026-02-18 18:27:21.4000000');
INSERT INTO Attendees_007 (attendee_id, email, password, full_name, phone, address, loyalty_points, created_at, updated_at) VALUES (3, N'adwoa.boateng@gmail.com', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'Adwoa Boateng', N'+233-27-555-6666', N'25 Liberation Road, Airport Residential, Accra', 520, N'2026-02-18 18:27:21.4000000', N'2026-02-18 18:27:21.4000000');
INSERT INTO Attendees_007 (attendee_id, email, password, full_name, phone, address, loyalty_points, created_at, updated_at) VALUES (4, N'kwadwo.ampofo@gmail.com', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'Kwadwo Ampofo', N'+233-55-777-8888', N'8 Adum Road, Kumasi', 25, N'2026-02-18 18:27:21.4000000', N'2026-02-18 18:27:21.4000000');
INSERT INTO Attendees_007 (attendee_id, email, password, full_name, phone, address, loyalty_points, created_at, updated_at) VALUES (5, N'efua.darko@gmail.com', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'Efua Darko', N'+233-24-999-0000', N'42 High Street, Takoradi', 1100, N'2026-02-18 18:27:21.4000000', N'2026-02-18 18:27:21.4000000');


-- Table: Audit_Log_007
IF OBJECT_ID(N'Audit_Log_007', N'U') IS NOT NULL DROP TABLE Audit_Log_007;
CREATE TABLE Audit_Log_007 (
    audit_id INT NOT NULL,
    user_id INT NULL,
    user_type NVARCHAR(20) NOT NULL,
    action_type NVARCHAR(50) NOT NULL,
    table_name NVARCHAR(50) NULL,
    record_id INT NULL,
    old_values NVARCHAR(MAX) NULL,
    new_values NVARCHAR(MAX) NULL,
    ip_address NVARCHAR(45) NULL,
    user_agent NVARCHAR(MAX) NULL,
    created_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (audit_id)
);


INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (1, 5, N'attendee', N'INSERT', N'Tickets_007', 7, NULL, N'{"ticket_id": 7, "event_id": 3, "ticket_number": "TKT-3-123462-700", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (2, 2, N'attendee', N'INSERT', N'Tickets_007', 6, NULL, N'{"ticket_id": 6, "event_id": 3, "ticket_number": "TKT-3-123461-600", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (3, 4, N'attendee', N'INSERT', N'Tickets_007', 5, NULL, N'{"ticket_id": 5, "event_id": 2, "ticket_number": "TKT-2-123460-500", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (4, 1, N'attendee', N'INSERT', N'Tickets_007', 4, NULL, N'{"ticket_id": 4, "event_id": 2, "ticket_number": "TKT-2-123459-400", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (5, 3, N'attendee', N'INSERT', N'Tickets_007', 3, NULL, N'{"ticket_id": 3, "event_id": 1, "ticket_number": "TKT-1-123458-300", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (6, 2, N'attendee', N'INSERT', N'Tickets_007', 2, NULL, N'{"ticket_id": 2, "event_id": 1, "ticket_number": "TKT-1-123457-200", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (7, 1, N'attendee', N'INSERT', N'Tickets_007', 1, NULL, N'{"ticket_id": 1, "event_id": 1, "ticket_number": "TKT-1-123456-100", "status": "booked"}', NULL, NULL, N'2026-02-18 18:27:21.4700000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (8, 1, N'attendee', N'LOGIN', N'Attendees_007', 1, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', N'2026-02-18 18:28:06.2600000');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (9, 1, N'attendee', N'LOGOUT', NULL, NULL, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36', N'2026-02-18 18:30:39.7533333');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (10, 1, N'admin', N'LOGIN', N'Admins_007', 1, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 12:30:00.8366667');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (11, 1, N'admin', N'LOGOUT', NULL, NULL, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 12:30:36.6533333');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (12, 1, N'organizer', N'LOGIN', N'Organizers_007', 1, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 12:34:16.5633333');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (13, 1, N'organizer', N'LOGOUT', NULL, NULL, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 12:34:40.2966667');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (14, 1, N'organizer', N'LOGIN', N'Organizers_007', 1, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 12:41:37.4866667');
INSERT INTO Audit_Log_007 (audit_id, user_id, user_type, action_type, table_name, record_id, old_values, new_values, ip_address, user_agent, created_at) VALUES (15, 1, N'admin', N'LOGIN', N'Admins_007', 1, N'[]', N'[]', N'::1', N'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', N'2026-02-19 23:16:11.3133333');


-- Table: Event_Vendors_007
IF OBJECT_ID(N'Event_Vendors_007', N'U') IS NOT NULL DROP TABLE Event_Vendors_007;
CREATE TABLE Event_Vendors_007 (
    event_vendor_id INT NOT NULL,
    event_id INT NOT NULL,
    vendor_id INT NOT NULL,
    service_description NVARCHAR(MAX) NULL,
    service_cost DECIMAL(10,2) NULL,
    assigned_date DATE NULL,
    PRIMARY KEY (event_vendor_id)
);


INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (1, 1, 1, N'Full catering services for all 3 days with traditional Ghanaian dishes', 25000.00, N'2026-03-15');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (2, 1, 2, N'AV equipment and technical support for presentations', 8000.00, N'2026-03-15');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (3, 2, 1, N'Food and beverage vendors for festival', 40000.00, N'2026-04-20');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (4, 2, 4, N'Event security personnel', 12000.00, N'2026-04-20');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (5, 3, 2, N'Presentation equipment and sound systems', 3500.00, N'2026-05-10');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (6, 4, 3, N'Stage decoration and lighting', 5000.00, N'2026-03-25');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (7, 6, 1, N'VIP catering services', 15000.00, N'2026-07-15');
INSERT INTO Event_Vendors_007 (event_vendor_id, event_id, vendor_id, service_description, service_cost, assigned_date) VALUES (8, 6, 4, N'Security for VIP guests', 10000.00, N'2026-07-15');


-- Table: Events_007
IF OBJECT_ID(N'Events_007', N'U') IS NOT NULL DROP TABLE Events_007;
CREATE TABLE Events_007 (
    event_id INT NOT NULL,
    organizer_id INT NOT NULL,
    venue_id INT NOT NULL,
    event_name NVARCHAR(200) NOT NULL,
    event_description NVARCHAR(MAX) NULL,
    event_date DATETIME2 NOT NULL,
    end_date DATETIME2 NULL,
    ticket_price DECIMAL(10,2) NOT NULL,
    max_capacity INT NOT NULL,
    event_status NVARCHAR(20) NULL DEFAULT ('draft'),
    created_at DATETIME2 NULL DEFAULT (getdate()),
    updated_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (event_id)
);


INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (1, 1, 1, N'Ghana Tech Summit 2026', N'Premier technology conference showcasing African innovation and startups', N'2026-03-15 09:00:00.0000000', N'2026-03-17 18:00:00.0000000', 450.00, 1500, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (2, 1, 2, N'Afrochella Music Festival', N'Celebrating African music, art, and culture over three amazing days', N'2026-04-20 12:00:00.0000000', N'2026-04-22 23:00:00.0000000', 200.00, 3000, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (3, 2, 3, N'Ghana Business Excellence Summit', N'Networking event for Ghana''s top business leaders and entrepreneurs', N'2026-05-10 08:00:00.0000000', N'2026-05-10 20:00:00.0000000', 750.00, 500, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (4, 2, 4, N'Comedy Night Accra', N'Stand-up comedy featuring Ghana''s funniest comedians', N'2026-03-25 19:00:00.0000000', N'2026-03-25 23:00:00.0000000', 100.00, 800, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (5, 3, 5, N'Kumasi Arts & Crafts Exhibition', N'Showcasing traditional and contemporary Ashanti art', N'2026-06-01 10:00:00.0000000', N'2026-06-30 18:00:00.0000000', 30.00, 2000, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (6, 1, 6, N'Pan-African Leadership Conference', N'Bringing together leaders from across the African continent', N'2026-07-15 08:00:00.0000000', N'2026-07-18 18:00:00.0000000', 1200.00, 400, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (7, 2, 7, N'Western Region Trade Fair', N'Exhibition of products and services from Western Ghana', N'2026-08-05 09:00:00.0000000', N'2026-08-12 18:00:00.0000000', 50.00, 500, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (8, 3, 1, N'Ghana Fashion Week', N'Showcasing the best of African fashion and design', N'2026-09-10 18:00:00.0000000', N'2026-09-13 22:00:00.0000000', 150.00, 1200, N'published', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');
INSERT INTO Events_007 (event_id, organizer_id, venue_id, event_name, event_description, event_date, end_date, ticket_price, max_capacity, event_status, created_at, updated_at) VALUES (9, 1, 2, N'Startup Grind Accra', N'Workshop series for aspiring entrepreneurs', N'2026-04-05 09:00:00.0000000', N'2026-04-05 17:00:00.0000000', 150.00, 200, N'draft', N'2026-02-18 18:27:21.3833333', N'2026-02-18 18:27:21.3833333');


-- Table: Organizers_007
IF OBJECT_ID(N'Organizers_007', N'U') IS NOT NULL DROP TABLE Organizers_007;
CREATE TABLE Organizers_007 (
    organizer_id INT NOT NULL,
    username NVARCHAR(50) NOT NULL,
    password NVARCHAR(255) NOT NULL,
    email NVARCHAR(100) NOT NULL,
    full_name NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20) NULL,
    company_name NVARCHAR(100) NULL,
    approval_status NVARCHAR(20) NULL DEFAULT ('pending'),
    created_at DATETIME2 NULL DEFAULT (getdate()),
    updated_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (organizer_id)
);


INSERT INTO Organizers_007 (organizer_id, username, password, email, full_name, phone, company_name, approval_status, created_at, updated_at) VALUES (1, N'organizer_kwame', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'kwame@eventghana.com', N'Kwame Asante', N'+233-20-123-4567', N'Asante Events Ghana', N'approved', N'2026-02-18 18:27:21.3366667', N'2026-02-18 18:27:21.3366667');
INSERT INTO Organizers_007 (organizer_id, username, password, email, full_name, phone, company_name, approval_status, created_at, updated_at) VALUES (2, N'organizer_ama', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'ama@eventghana.com', N'Ama Mensah', N'+233-24-567-8901', N'Mensah Productions Ltd', N'approved', N'2026-02-18 18:27:21.3366667', N'2026-02-18 18:27:21.3366667');
INSERT INTO Organizers_007 (organizer_id, username, password, email, full_name, phone, company_name, approval_status, created_at, updated_at) VALUES (3, N'organizer_kofi', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'kofi@eventghana.com', N'Kofi Boateng', N'+233-27-901-2345', N'Boateng Events & Co.', N'pending', N'2026-02-18 18:27:21.3366667', N'2026-02-18 18:27:21.3366667');
INSERT INTO Organizers_007 (organizer_id, username, password, email, full_name, phone, company_name, approval_status, created_at, updated_at) VALUES (4, N'organizer_akua', N'$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', N'akuamensah@gmail.com', N'Akua Mensah', N'+233-20-000-0000', N'Akua Events Ghana', N'approved', N'2026-02-18 18:27:21.3366667', N'2026-02-18 18:27:21.3366667');


-- Table: Payments_007
IF OBJECT_ID(N'Payments_007', N'U') IS NOT NULL DROP TABLE Payments_007;
CREATE TABLE Payments_007 (
    payment_id INT NOT NULL,
    ticket_id INT NOT NULL,
    attendee_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method NVARCHAR(50) NOT NULL,
    payment_status NVARCHAR(20) NULL DEFAULT ('pending'),
    payment_date DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (payment_id)
);


INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (1, 1, 1, 450.00, N'credit_card', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (2, 2, 2, 450.00, N'debit_card', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (3, 3, 3, 450.00, N'online', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (4, 4, 1, 200.00, N'credit_card', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (5, 5, 4, 200.00, N'credit_card', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (6, 6, 2, 750.00, N'credit_card', N'completed', N'2026-02-18 18:27:21.4966667');
INSERT INTO Payments_007 (payment_id, ticket_id, attendee_id, amount, payment_method, payment_status, payment_date) VALUES (7, 7, 5, 750.00, N'online', N'completed', N'2026-02-18 18:27:21.4966667');


-- Table: Tickets_007
IF OBJECT_ID(N'Tickets_007', N'U') IS NOT NULL DROP TABLE Tickets_007;
CREATE TABLE Tickets_007 (
    ticket_id INT NOT NULL,
    event_id INT NOT NULL,
    attendee_id INT NOT NULL,
    ticket_number NVARCHAR(20) NOT NULL,
    ticket_status NVARCHAR(20) NULL DEFAULT ('booked'),
    booking_date DATETIME2 NULL DEFAULT (getdate()),
    check_in_time DATETIME2 NULL,
    PRIMARY KEY (ticket_id)
);


INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (1, 1, 1, N'TKT-1-123456-100', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (2, 1, 2, N'TKT-1-123457-200', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (3, 1, 3, N'TKT-1-123458-300', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (4, 2, 1, N'TKT-2-123459-400', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (5, 2, 4, N'TKT-2-123460-500', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (6, 3, 2, N'TKT-3-123461-600', N'booked', N'2026-02-18 18:27:21.4600000', NULL);
INSERT INTO Tickets_007 (ticket_id, event_id, attendee_id, ticket_number, ticket_status, booking_date, check_in_time) VALUES (7, 3, 5, N'TKT-3-123462-700', N'booked', N'2026-02-18 18:27:21.4600000', NULL);


-- Table: Vendors_007
IF OBJECT_ID(N'Vendors_007', N'U') IS NOT NULL DROP TABLE Vendors_007;
CREATE TABLE Vendors_007 (
    vendor_id INT NOT NULL,
    vendor_name NVARCHAR(100) NOT NULL,
    vendor_type NVARCHAR(50) NOT NULL,
    contact_person NVARCHAR(100) NULL,
    email NVARCHAR(100) NULL,
    phone NVARCHAR(20) NULL,
    rating DECIMAL(3,2) NULL DEFAULT ((0)),
    created_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (vendor_id)
);


INSERT INTO Vendors_007 (vendor_id, vendor_name, vendor_type, contact_person, email, phone, rating, created_at) VALUES (1, N'Authentic Ghanaian Cuisine', N'Catering', N'Chef Adwoa', N'adwoa@authenticghcuisine.com', N'+233-20-100-2001', 4.80, N'2026-02-18 18:27:21.4133333');
INSERT INTO Vendors_007 (vendor_id, vendor_name, vendor_type, contact_person, email, phone, rating, created_at) VALUES (2, N'AfroBeats Sound Systems', N'Audio/Visual', N'DJ Kofi', N'kofi@afrobeatsound.com', N'+233-24-100-2002', 4.50, N'2026-02-18 18:27:21.4133333');
INSERT INTO Vendors_007 (vendor_id, vendor_name, vendor_type, contact_person, email, phone, rating, created_at) VALUES (3, N'Kente Kingdom Decor', N'Decoration', N'Nana Yaw', N'nana@kentekingdom.com', N'+233-27-100-2003', 4.70, N'2026-02-18 18:27:21.4133333');
INSERT INTO Vendors_007 (vendor_id, vendor_name, vendor_type, contact_person, email, phone, rating, created_at) VALUES (4, N'Secure Ghana Services', N'Security', N'Mr. Asante', N'asante@secureghana.com', N'+233-55-100-2004', 4.90, N'2026-02-18 18:27:21.4133333');
INSERT INTO Vendors_007 (vendor_id, vendor_name, vendor_type, contact_person, email, phone, rating, created_at) VALUES (5, N'Stage Masters Ghana', N'Equipment', N'Mr. Mensah', N'mensah@stagemastersgh.com', N'+233-24-100-2005', 4.60, N'2026-02-18 18:27:21.4133333');


-- Table: Venues_007
IF OBJECT_ID(N'Venues_007', N'U') IS NOT NULL DROP TABLE Venues_007;
CREATE TABLE Venues_007 (
    venue_id INT NOT NULL,
    venue_name NVARCHAR(100) NOT NULL,
    address NVARCHAR(255) NOT NULL,
    city NVARCHAR(100) NOT NULL,
    state NVARCHAR(50) NULL,
    zip_code NVARCHAR(20) NULL,
    capacity INT NOT NULL,
    amenities NVARCHAR(MAX) NULL,
    created_at DATETIME2 NULL DEFAULT (getdate()),
    PRIMARY KEY (venue_id)
);


INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (1, N'Accra International Conference Centre', N'Independence Avenue, Ridge', N'Accra', N'Greater Accra', 00233, 2000, N'WiFi, Air Conditioning, Catering, AV Equipment, Parking', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (2, N'National Theatre of Ghana', N'Independence Avenue', N'Accra', N'Greater Accra', 00233, 1500, N'Stage, Sound System, Green Room, Lighting', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (3, N'Kwame Nkrumah Memorial Park', N'High Street', N'Accra', N'Greater Accra', 00233, 5000, N'Outdoor Space, Historical Site, Parking, Security', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (4, N'University of Ghana Legon Auditorium', N'Legon Campus', N'Accra', N'Greater Accra', 00233, 1200, N'WiFi, Projector, Air Conditioning, Parking', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (5, N'Kumasi Cultural Centre', N'Bantama Road', N'Kumasi', N'Ashanti', 00233, 3000, N'Cultural Exhibits, Outdoor Space, Parking, Food Court', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (6, N'Labadi Beach Hotel Conference Hall', N'Labadi Beach Road', N'Accra', N'Greater Accra', 00233, 800, N'Beach View, WiFi, Catering, AC, Swimming Pool Access', N'2026-02-18 18:27:21.3500000');
INSERT INTO Venues_007 (venue_id, venue_name, address, city, state, zip_code, capacity, amenities, created_at) VALUES (7, N'Takoradi Mall Event Space', N'Market Circle', N'Takoradi', N'Western', 00233, 600, N'Modern Facilities, WiFi, Parking, Food Court', N'2026-02-18 18:27:21.3500000');


